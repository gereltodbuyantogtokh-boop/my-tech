# LIFE HOTEL — PUB / KARAOKE

Premium dark nightlife landing — gold #FFD700, magenta #FF006B, bg #08080F.

A clean, no-glitch hero: **LIFE / HOTEL / PUB / KARAOKE** — 3 lines, glassmorphism, 70 twinkling stars.

## Features
- Dark premium UI with glassmorphism
- Syne + Space Grotesk + Caveat fonts
- Hero with 2 pills: Book Hotel Room (gold) & Book Karaoke VIP (magenta)
- Combo 199k card: Room + Karaoke + Bar credit
- Midnight location with SVG map
- Stars twinkle — 70 dots, pure CSS/JS

## Stack
Static single file — `index.html` only. No build step.

## GitHub Pages Deploy

1. **Create repo** on GitHub: `life-hotel`
2. Upload files: `index.html`, `README.md`, `.gitignore`
3. Go to **Settings → Pages**
4. Source: **Deploy from a branch** → Branch: **main** / **root**
5. Save — your site will be live at `https://<username>.github.io/life-hotel/`

Or via Git CLI:
```bash
git init
git add .
git commit -m "LIFE HOTEL launch"
git branch -M main
git remote add origin https://github.com/<username>/life-hotel.git
git push -u origin main
```

Enable Pages after first push.

## Custom Domain (optional)
Add `CNAME` file with your domain and configure DNS.

---
Built for midnight — Saigon.
